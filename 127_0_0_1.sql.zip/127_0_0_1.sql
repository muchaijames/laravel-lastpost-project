-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2021 at 04:09 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lastpost`
--
CREATE DATABASE IF NOT EXISTS `lastpost` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `lastpost`;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--
-- Creation: Nov 16, 2021 at 08:51 AM
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `failed_jobs`:
--

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--
-- Creation: Dec 12, 2021 at 01:47 PM
--

CREATE TABLE `likes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `likes`:
--   `post_id`
--       `posts` -> `id`
--   `user_id`
--       `users` -> `id`
--

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `user_id`, `post_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(74, 10, 243, '2021-12-12 11:23:07', '2021-12-12 11:23:44', '2021-12-12 11:23:44'),
(75, 10, 243, '2021-12-12 11:23:47', '2021-12-12 11:24:26', '2021-12-12 11:24:26'),
(76, 10, 243, '2021-12-12 11:24:29', '2021-12-12 11:24:47', '2021-12-12 11:24:47'),
(77, 10, 243, '2021-12-12 11:24:49', '2021-12-12 11:40:25', '2021-12-12 11:40:25'),
(78, 10, 243, '2021-12-12 11:40:30', '2021-12-13 14:30:54', '2021-12-13 14:30:54'),
(79, 10, 245, '2021-12-13 14:30:29', '2021-12-13 14:32:39', '2021-12-13 14:32:39'),
(80, 10, 243, '2021-12-13 14:31:32', '2021-12-13 15:04:00', '2021-12-13 15:04:00'),
(81, 10, 245, '2021-12-13 14:32:41', '2021-12-13 14:32:44', '2021-12-13 14:32:44'),
(82, 10, 245, '2021-12-13 14:32:48', '2021-12-13 15:03:52', '2021-12-13 15:03:52'),
(83, 10, 245, '2021-12-13 15:03:57', '2021-12-13 15:04:04', '2021-12-13 15:04:04'),
(84, 10, 246, '2021-12-17 07:47:53', '2021-12-17 07:47:53', NULL),
(85, 10, 247, '2021-12-17 07:49:10', '2021-12-17 07:49:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--
-- Creation: Nov 16, 2021 at 08:51 AM
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `migrations`:
--

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_11_16_085633_add_username_to_users_table', 2),
(6, '2021_11_19_171719_create_posts_table', 3),
(7, '2021_11_28_055332_create_likes_table', 4),
(9, '2021_12_12_132544_add_soft_deletes_to_likes_table', 5),
(10, '2021_12_12_134204_add_soft_deletes_to_likes_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--
-- Creation: Nov 19, 2021 at 05:39 PM
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `posts`:
--   `user_id`
--       `users` -> `id`
--

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `body`, `created_at`, `updated_at`) VALUES
(232, 9, 'My name is Joyce Wanjiku Njaramba... i love Muchai James', '2021-11-29 06:02:12', '2021-11-29 06:02:12'),
(233, 9, 'My name is Joyce...the ICT guru', '2021-11-29 06:24:29', '2021-11-29 06:24:29'),
(235, 10, 'my name is James Muchai', '2021-11-29 06:36:37', '2021-11-29 06:36:37'),
(237, 9, 'hello james', '2021-12-03 16:46:22', '2021-12-03 16:46:22'),
(238, 9, 'today is a good day', '2021-12-12 04:12:04', '2021-12-12 04:12:04'),
(239, 10, 'hae, joyce how r u doing', '2021-12-12 04:58:37', '2021-12-12 04:58:37'),
(240, 10, 'habari yako', '2021-12-12 04:59:00', '2021-12-12 04:59:00'),
(241, 10, 'hello', '2021-12-12 05:06:50', '2021-12-12 05:06:50'),
(243, 11, 'muchai, my love', '2021-12-12 05:42:05', '2021-12-12 05:42:05'),
(245, 12, 'hello...leo nakula unga na sukuma', '2021-12-13 14:27:40', '2021-12-13 14:27:40'),
(246, 10, 'denno ni bazuuu', '2021-12-17 07:45:55', '2021-12-17 07:45:55'),
(247, 10, 'i love joy wanjiku', '2021-12-17 07:49:01', '2021-12-17 07:49:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Nov 16, 2021 at 09:03 AM
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- RELATIONSHIPS FOR TABLE `users`:
--

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `username`) VALUES
(9, 'Joyce Wanjiku', 'Joyshiks@gmail.com', NULL, '$2y$10$3hrLyKG9Vs40XYI9XPHCneH1zIEzOMLCuuMzw7QFgH7gVrvKrzsFy', 'Bao4hZuyCbJdSE1A1ba1GloU82lUjUNB4InD0sQXtHNnkJt4FFK5zzPvpmYo', '2021-11-28 16:24:33', '2021-11-28 16:24:33', 'joy'),
(10, 'James Njuguna', 'muchaijames11@gmail.com', NULL, '$2y$10$kTtqnXmkpQxmZx2fFC4jneKelLgmL0utCRl9E0dichYIoNoCji6UK', NULL, '2021-11-28 16:37:15', '2021-11-28 16:37:15', 'jymothedeveloper'),
(11, 'Pesh Wambui', 'Peshwamb12@gmail.com', NULL, '$2y$10$FqFZmp93zxXuQhkdF1Zxu.9aFiGDHISRRSbZYdXI4b/cWnH0LBmOS', NULL, '2021-12-12 05:40:25', '2021-12-12 05:40:25', 'Peshwamb'),
(12, 'Dennis Wachira', 'dennowachira11@gmail.com', NULL, '$2y$10$B7kgFoZmpzYgDTH080Mv4uhKrEMVy9lIvQHTmRAX2Id80sTHD/Ikm', NULL, '2021-12-13 14:24:20', '2021-12-13 14:24:20', 'denno');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `likes_user_id_foreign` (`user_id`),
  ADD KEY `likes_post_id_foreign` (`post_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_user_id_foreign` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=248;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
